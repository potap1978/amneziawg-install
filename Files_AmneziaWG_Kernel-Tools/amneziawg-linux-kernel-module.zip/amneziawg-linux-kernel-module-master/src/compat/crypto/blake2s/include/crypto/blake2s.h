#include <zinc/blake2s.h>
