#ifndef _AWG_COMPAT_NET_GSO
#define _AWG_COMPAT_NET_GSO

#include <linux/netdevice.h>

#endif